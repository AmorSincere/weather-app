
# Weather app

this app shows weather informations

## Documentation

[Documentation](https://www.visualcrossing.com/resources/documentation/weather-api/timeline-weather-api/)

## Design

[youtube-Coen](https://www.youtube.com/watch?v=CMp4Gjuv6L0)

