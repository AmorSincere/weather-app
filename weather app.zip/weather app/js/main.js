var country_code = ""
$.getJSON('https://geolocation-db.com/json/')
    .done(function (location) {
        country_code = location.country_code;
    });


window.onload = (event) => {
 
    fetch("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/Tashkent,UZ/today?key=AT4GNGT6YMPMLXHMPEAT46T4J&contentType=json", {
        method: 'GET',
        headers: {

        },
    }).then(response => {
        if (!response.ok) {
            console.log("it says ok!")
            throw response; //check the http response code and if isn't ok then throw the response as an error
        }
        return response.json(); //parse the result as JSON

    }).then(response => {
        //response now contains parsed JSON ready for use
        // processWeatherData(response);
        console.log("Response", response, response.days[0]);
        if (response.days[0].icon == 'cloudy') {
            document.querySelector('.icon').src = "./images/cloud.png";
            document.querySelector('.condition').innerHTML = response.days[0].conditions;


        }
        let temprature = parseInt((response.days[0].temp - 32) * (5 / 9));
        let informationsWeather = "description:" + response.description;
        document.getElementById("informations").innerHTML = informationsWeather;
        document.querySelector('.degree').innerHTML = temprature + "&#176;";
        document.querySelector('.name').innerHTML = "Tashkent";
        document.querySelector('.cloud').innerHTML = response.days[0].cloudcover + "%";
        document.querySelector('.humiditiy').innerHTML = response.days[0].humidity + "%";
        document.querySelector('.wind').innerHTML = response.days[0].windspeed + " km/h";


    }).catch((errorResponse) => {
        if (errorResponse.text) { //additional error information
            errorResponse.text().then(errorMessage => {
                console.log("errorMessage", errorMessage)
                document.getElementById("informations").innerHTML = errorMessage;
                //errorMessage now returns the response body which includes the full error message
            })
        } else {
            console.log("no additinal data")
            //no additional error information;
            document.getElementById("informations").innerHTML = "no additional data!";
        }
    });
    event.preventDefault()
};


function weatherFetch(event) {
    let locationText = document.getElementById("locationValue").value
    console.log(locationText)
    fetch("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/" + locationText + "," + country_code + "/today?key=AT4GNGT6YMPMLXHMPEAT46T4J&contentType=json", {
        method: 'GET',
        headers: {

        },
    }).then(response => {
        if (!response.ok) {
            console.log("it says ok!")
            throw response; //check the http response code and if isn't ok then throw the response as an error
        }
        return response.json(); //parse the result as JSON

    }).then(response => {
        //response now contains parsed JSON ready for use
        // processWeatherData(response);
        console.log("Response", response, response.days[0]);
        if (response.days[0].icon.includes('cloud')) {
            document.querySelector('.icon').src = "./images/cloud.png";
            document.querySelector('.condition').innerHTML = response.days[0].conditions;
        }
        else if (response.days[0].icon.includes('rain')) {
            document.querySelector('.icon').src = "./images/rain.png";
            document.querySelector('.condition').innerHTML = response.days[0].conditions;
        }
        else if (response.days[0].icon.includes('clear-day')) {
            document.querySelector('.icon').src = "./images/sun.png";
            document.querySelector('.condition').innerHTML = response.days[0].conditions;
        }
        let temprature = parseInt((response.days[0].temp - 32) * (5 / 9));
        let informationsWeather = "description:" + response.description;
        document.getElementById("informations").innerHTML = informationsWeather;
        document.querySelector('.degree').innerHTML = temprature + "&#176;";
        document.querySelector('.name').innerHTML = locationText;
        document.querySelector('.cloud').innerHTML = response.days[0].cloudcover + "%";
        document.querySelector('.humiditiy').innerHTML = response.days[0].humidity + "%";
        document.querySelector('.wind').innerHTML = response.days[0].windspeed + " km/h";


    }).catch((errorResponse) => {
        if (errorResponse.text) { //additional error information
            errorResponse.text().then(errorMessage => {
                console.log("errorMessage", errorMessage)
                document.getElementById("informations").innerHTML = errorMessage;
                //errorMessage now returns the response body which includes the full error message
            })
        } else {
            console.log("no additinal data")
            //no additional error information;
            document.getElementById("informations").innerHTML = "no additional data!";
        }
    });
    event.preventDefault()
}

const form = document.getElementById('locationInput');
form.addEventListener('submit', weatherFetch);

function reccomendationPlaces(location_reccommend) {

    console.log(location_reccommend);
    fetch("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/" + location_reccommend + ",UZ/today?key=AT4GNGT6YMPMLXHMPEAT46T4J&contentType=json", {
        method: 'GET',
        headers: {

        },
    }).then(response => {
        if (!response.ok) {
            console.log("it says ok!")
            throw response; //check the http response code and if isn't ok then throw the response as an error
        }
        return response.json(); //parse the result as JSON

    }).then(response => {
        //response now contains parsed JSON ready for use
        // processWeatherData(response);
        console.log("Response", response, response.days[0]);
        if (response.days[0].icon.includes('cloud')) {
            document.querySelector('.icon').src = "./images/cloud.png";
            document.querySelector('.condition').innerHTML = response.days[0].conditions;
        }
        else if (response.days[0].icon.includes('rain')) {
            document.querySelector('.icon').src = "./images/rain.png";
            document.querySelector('.condition').innerHTML = response.days[0].conditions;
        }
        else if (response.days[0].icon.includes('clear-day')) {
            document.querySelector('.icon').src = "./images/sun.png";
            document.querySelector('.condition').innerHTML = response.days[0].conditions;
        }
        let temprature = parseInt((response.days[0].temp - 32) * (5 / 9));
        let informationsWeather = "description:" + response.description;
        document.getElementById("informations").innerHTML = informationsWeather;
        document.querySelector('.degree').innerHTML = temprature + "&#176;";
        document.querySelector('.name').innerHTML = location_reccommend;
        document.querySelector('.cloud').innerHTML = response.days[0].cloudcover + "%";
        document.querySelector('.humiditiy').innerHTML = response.days[0].humidity + "%";
        document.querySelector('.wind').innerHTML = response.days[0].windspeed + " km/h";
        locationText = document.getElementById("locationValue").value = location_reccommend;


    }).catch((errorResponse) => {
        if (errorResponse.text) { //additional error information
            errorResponse.text().then(errorMessage => {
                console.log("errorMessage", errorMessage)
                document.getElementById("informations").innerHTML = errorMessage;
                //errorMessage now returns the response body which includes the full error message
            })
        } else {
            console.log("no additinal data")
            //no additional error information;
            document.getElementById("informations").innerHTML = "no additional data!";
        }
    });
    event.preventDefault()

}

